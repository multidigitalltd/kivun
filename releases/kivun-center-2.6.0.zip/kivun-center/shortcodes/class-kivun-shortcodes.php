<?php
/**
 * Front-end shortcode handlers for the Kivun Center plugin.
 *
 * @package Kivun
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers and renders the Kivun Center shortcodes.
 */
class Kivun_Shortcodes {

	/**
	 * Register all plugin shortcodes.
	 *
	 * @return void
	 */
	public static function init(): void {
		$map = array(
			'kivun_courses'            => 'render_courses',
			'kivun_course_single'      => 'render_course_single',
			'kivun_course_register'    => 'render_course_register',
			'kivun_course_id'          => 'render_course_id',
			'kivun_post_id'            => 'render_post_id',
			'kivun_session_status'     => 'render_session_status',
			'kivun_event_register'     => 'render_event_register',
			'kivun_course_interest'    => 'render_course_interest',
			'kivun_workshops'          => 'render_workshops',
			'kivun_workshop_single'    => 'render_workshop_single',
			'kivun_jobs'               => 'render_jobs',
			'kivun_apply'              => 'render_apply',
			'kivun_spots_left'         => 'render_spots_left',
			'kivun_my_applications'    => 'render_my_applications',
			'kivun_employer_register'  => 'render_employer_register',
			'kivun_employer_dashboard' => 'render_employer_dashboard',
		);

		foreach ( $map as $tag => $method ) {
			add_shortcode( $tag, array( __CLASS__, $method ) );
		}
	}

	// ── Courses archive ───────────────────────────────────────────────────────

	/**
	 * Render the courses archive grid.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Rendered HTML markup.
	 */
	public static function render_courses( array $atts ): string {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'per_page' => 12,
				'columns'  => 3,
				'orderby'  => 'date',
			),
			$atts,
			'kivun_courses'
		);

		$args = array(
			'post_type'      => 'kivun_course',
			'post_status'    => 'publish',
			'posts_per_page' => (int) $atts['per_page'],
			'orderby'        => sanitize_key( $atts['orderby'] ),
			'order'          => 'DESC',
		);

		if ( $atts['category'] ) {
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'kivun_course_cat',
					'field'    => 'slug',
					'terms'    => sanitize_text_field( $atts['category'] ),
				),
			);
		}

		$query = new WP_Query( $args );

		ob_start();
		kivun_get_template(
			'courses/archive.php',
			array(
				'query'   => $query,
				'columns' => (int) $atts['columns'],
			)
		);
		wp_reset_postdata();

		return ob_get_clean();
	}

	// ── Single course ─────────────────────────────────────────────────────────

	/**
	 * Render a single course view.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Rendered HTML markup.
	 */
	public static function render_course_single( array $atts ): string {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'kivun_course_single' );
		$id   = absint( $atts['id'] ) ? absint( $atts['id'] ) : get_the_ID();

		if ( 'kivun_course' !== get_post_type( $id ) ) {
			return '';
		}

		ob_start();
		kivun_get_template( 'courses/single.php', array( 'course_id' => $id ) );
		return ob_get_clean();
	}

	// ── Course registration form ──────────────────────────────────────────────

	/**
	 * Render the course registration form.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Rendered HTML markup.
	 */
	public static function render_course_register( array $atts ): string {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'kivun_course_register' );
		$id   = absint( $atts['id'] ) ? absint( $atts['id'] ) : get_the_ID();

		if ( get_post_type( $id ) !== 'kivun_course' ) {
			return '';
		}

		ob_start();
		kivun_get_template( 'courses/register-form.php', array( 'course_id' => $id ) );
		return ob_get_clean();
	}

	// ── Course interest form ──────────────────────────────────────────────────

	/**
	 * Render the course interest form.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Rendered HTML markup.
	 */
	public static function render_course_interest( array $atts ): string {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'kivun_course_interest' );
		$id   = absint( $atts['id'] ) ? absint( $atts['id'] ) : get_the_ID();

		if ( get_post_type( $id ) !== 'kivun_course' ) {
			return '';
		}

		ob_start();
		kivun_get_template(
			'courses/interest-form.php',
			array(
				'post_id'   => $id,
				'post_type' => 'kivun_course',
			)
		);
		return ob_get_clean();
	}

	// ── Workshops archive ─────────────────────────────────────────────────────

	/**
	 * Render the workshops archive grid.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Rendered HTML markup.
	 */
	public static function render_workshops( array $atts ): string {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'per_page' => 12,
				'columns'  => 3,
			),
			$atts,
			'kivun_workshops'
		);

		$args = array(
			'post_type'      => 'kivun_workshop',
			'post_status'    => 'publish',
			'posts_per_page' => (int) $atts['per_page'],
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		if ( $atts['category'] ) {
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'kivun_workshop_cat',
					'field'    => 'slug',
					'terms'    => sanitize_text_field( $atts['category'] ),
				),
			);
		}

		$query = new WP_Query( $args );

		ob_start();
		kivun_get_template(
			'workshops/archive.php',
			array(
				'query'   => $query,
				'columns' => (int) $atts['columns'],
			)
		);
		wp_reset_postdata();

		return ob_get_clean();
	}

	// ── Workshop single ───────────────────────────────────────────────────────

	/**
	 * Render a single workshop view.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Rendered HTML markup.
	 */
	public static function render_workshop_single( array $atts ): string {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'kivun_workshop_single' );
		$id   = absint( $atts['id'] ) ? absint( $atts['id'] ) : get_the_ID();

		if ( get_post_type( $id ) !== 'kivun_workshop' ) {
			return '';
		}

		ob_start();
		kivun_get_template( 'workshops/single.php', array( 'workshop_id' => $id ) );
		return ob_get_clean();
	}

	// ── Jobs board ────────────────────────────────────────────────────────────

	/**
	 * Render the jobs board archive.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Rendered HTML markup.
	 */
	public static function render_jobs( array $atts ): string {
		$atts = shortcode_atts(
			array(
				'show_filters' => 'yes',
				'per_page'     => 10,
				'scope'        => '',
				'region'       => '',
				'field'        => '',
			),
			$atts,
			'kivun_jobs'
		);

		$args = array(
			'post_type'      => 'kivun_job',
			'post_status'    => 'publish',
			'posts_per_page' => (int) $atts['per_page'],
			'orderby'        => 'date',
			'order'          => 'DESC',
			// A job that has been filled drops off once its grace runs out.
			'meta_query'     => Kivun_Jobs::board_meta_query(), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		);

		$tax_query = array();
		foreach ( array(
			'scope'  => 'kivun_job_scope',
			'region' => 'kivun_job_region',
			'field'  => 'kivun_job_field',
		) as $key => $tax ) {
			if ( $atts[ $key ] ) {
				$tax_query[] = array(
					'taxonomy' => $tax,
					'field'    => 'slug',
					'terms'    => sanitize_text_field( $atts[ $key ] ),
				);
			}
		}
		if ( $tax_query ) {
			if ( count( $tax_query ) > 1 ) {
				$tax_query['relation'] = 'AND';
			}
			$args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		}

		$query = new WP_Query( $args );

		ob_start();
		kivun_get_template(
			'jobs/archive.php',
			array(
				'query'        => $query,
				'show_filters' => 'yes' === $atts['show_filters'],
			)
		);
		wp_reset_postdata();

		return ob_get_clean();
	}

	// ── Spots left ────────────────────────────────────────────────────────────

	/**
	 * Render the number of spots left for a course or workshop.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Rendered HTML markup.
	 */
	public static function render_spots_left( array $atts ): string {
		$atts = shortcode_atts(
			array(
				'id'        => 0,
				'full_text' => 'מלא',
			),
			$atts,
			'kivun_spots_left'
		);
		$id   = absint( $atts['id'] ) ? absint( $atts['id'] ) : get_the_ID();

		$left = kivun_get_spots_left( $id );
		if ( null === $left ) {
			return '';
		}

		if ( 0 === $left ) {
			return '<span class="kivun-spots kivun-spots--full">' . esc_html( $atts['full_text'] ) . '</span>';
		}

		return '<span class="kivun-spots">' . sprintf(
			/* translators: %d: number of available spots. */
			esc_html__( 'נותרו %d מקומות', 'kivun' ),
			$left
		) . '</span>';
	}

	// ── CV application form ───────────────────────────────────────────────────

	/**
	 * Render the CV application form for a job.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Rendered HTML markup.
	 */
	public static function render_apply( array $atts ): string {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'kivun_apply' );
		$id   = absint( $atts['id'] ) ? absint( $atts['id'] ) : get_the_ID();

		// Fallback for contexts rendered outside the main loop (e.g. an
		// Elementor Off-Canvas / Popup), where get_the_ID() is unreliable.
		if ( get_post_type( $id ) !== 'kivun_job' ) {
			$queried = get_queried_object_id();
			if ( $queried && 'kivun_job' === get_post_type( $queried ) ) {
				$id = $queried;
			}
		}

		if ( get_post_type( $id ) !== 'kivun_job' ) {
			return '';
		}

		ob_start();
		kivun_get_template( 'jobs/apply-form.php', array( 'job_id' => $id ) );
		return ob_get_clean();
	}

	/**
	 * Output the current course ID — for binding an Elementor hidden field
	 * (via a "Shortcode" dynamic tag) so the Forms action knows which course
	 * the visitor is on, even inside a shared single template.
	 *
	 * @return string The course ID, or empty string when not on a course.
	 */
	public static function render_course_id(): string {
		$id = (int) get_the_ID();

		if ( get_post_type( $id ) !== 'kivun_course' ) {
			$queried = get_queried_object_id();
			if ( $queried && 'kivun_course' === get_post_type( $queried ) ) {
				$id = (int) $queried;
			}
		}

		return get_post_type( $id ) === 'kivun_course' ? (string) $id : '';
	}

	/**
	 * Output the current Kivun post ID (course or landing page) — for binding an
	 * Elementor hidden field on a shared single template so the Forms action
	 * knows which item the visitor is on.
	 *
	 * @return string The post ID, or empty string when not on a Kivun item.
	 */
	public static function render_post_id(): string {
		$id = (int) get_the_ID();

		if ( ! in_array( get_post_type( $id ), array( 'kivun_course', 'kivun_workshop', 'kivun_session', 'kivun_event' ), true ) ) {
			$queried = get_queried_object_id();
			if ( $queried && in_array( get_post_type( $queried ), array( 'kivun_course', 'kivun_workshop', 'kivun_session', 'kivun_event' ), true ) ) {
				$id = (int) $queried;
			}
		}

		return in_array( get_post_type( $id ), array( 'kivun_course', 'kivun_workshop', 'kivun_session', 'kivun_event' ), true ) ? (string) $id : '';
	}

	/**
	 * Render a "registration closed" notice for a session whose validity date has
	 * passed. Outputs nothing while registration is still open (unless an "open"
	 * message is supplied). Built for Elementor pages — drop it into a Shortcode
	 * or HTML widget above the form.
	 *
	 * Attributes:
	 *  - id     : Session ID (default: the current/queried session).
	 *  - closed : Message shown when registration is closed.
	 *  - open   : Optional message shown while registration is open (default: none).
	 *
	 * @param mixed $atts Shortcode attributes.
	 * @return string Rendered HTML, or empty string.
	 */
	public static function render_session_status( $atts ): string {
		$atts = shortcode_atts(
			array(
				'id'     => 0,
				'closed' => '',
				'open'   => '',
			),
			$atts,
			'kivun_session_status'
		);

		$types = array( 'kivun_session', 'kivun_event' );

		$id = absint( $atts['id'] );
		if ( ! $id ) {
			$id = (int) get_the_ID();
			if ( ! in_array( get_post_type( $id ), $types, true ) ) {
				$queried = get_queried_object_id();
				if ( $queried && in_array( get_post_type( $queried ), $types, true ) ) {
					$id = (int) $queried;
				}
			}
		}

		$post_type = get_post_type( $id );
		if ( ! in_array( $post_type, $types, true ) ) {
			return '';
		}

		$is_event = ( 'kivun_event' === $post_type );
		$is_open  = $is_event ? kivun_event_registration_open( $id ) : kivun_session_registration_open( $id );

		if ( $is_open ) {
			return '' !== trim( (string) $atts['open'] )
				? '<div class="kivun-session-status kivun-session-status--open" role="status">' . esc_html( $atts['open'] ) . '</div>'
				: '';
		}

		$closed = trim( (string) $atts['closed'] );
		if ( '' === $closed ) {
			$closed = $is_event
				? __( 'ההרשמה לאירוע נסגרה — האירוע כבר התקיים.', 'kivun' )
				: __( 'המחזור הנוכחי נסגר — הרשמו עכשיו ונעדכן אתכם כשייפתח המחזור הבא.', 'kivun' );
		}

		$icon = '<svg class="kivun-session-status__icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16Zm1-13h-2v6l5 3 1-1.7-4-2.3V7Z"/></svg>';

		return '<div class="kivun-session-status kivun-session-status--closed" role="status">'
			. $icon
			. '<span>' . esc_html( $closed ) . '</span>'
			. '</div>';
	}

	/**
	 * Render the event registration area: a closed notice after the event, a
	 * button to an external system, or a built-in form (saved to the leads table
	 * with source/UTM) — per the event's "אופן ההרשמה" setting.
	 *
	 * @param mixed $atts Shortcode attributes (id).
	 * @return string
	 */
	public static function render_event_register( $atts ): string {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'kivun_event_register' );

		$id = absint( $atts['id'] );
		if ( ! $id ) {
			$id = (int) get_the_ID();
			if ( 'kivun_event' !== get_post_type( $id ) ) {
				$queried = get_queried_object_id();
				if ( $queried && 'kivun_event' === get_post_type( $queried ) ) {
					$id = (int) $queried;
				}
			}
		}
		if ( 'kivun_event' !== get_post_type( $id ) ) {
			return '';
		}

		$icon = '<svg class="kivun-session-status__icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16Zm1-13h-2v6l5 3 1-1.7-4-2.3V7Z"/></svg>';

		if ( ! kivun_event_registration_open( $id ) ) {
			return '<div class="kivun-session-status kivun-session-status--closed" role="status">' . $icon . '<span>' . esc_html__( 'ההרשמה לאירוע נסגרה — האירוע כבר התקיים.', 'kivun' ) . '</span></div>';
		}
		if ( kivun_is_full( $id ) ) {
			return '<div class="kivun-session-status kivun-session-status--closed" role="status">' . $icon . '<span>' . esc_html__( 'ההרשמה לאירוע מלאה.', 'kivun' ) . '</span></div>';
		}

		if ( 'external' === kivun_event_mode( $id ) ) {
			$url = (string) get_post_meta( $id, '_kivun_event_external_url', true );
			if ( '' === trim( $url ) ) {
				return '';
			}
			$label = (string) get_post_meta( $id, '_kivun_event_button', true );
			if ( '' === trim( $label ) ) {
				$label = __( 'להרשמה לאירוע', 'kivun' );
			}
			return '<div class="kivun-event-register"><a class="kivun-event-register__btn" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $label ) . '</a></div>';
		}

		ob_start();
		kivun_get_template(
			'events/register-form.php',
			array(
				'post_id'   => $id,
				'post_type' => 'kivun_event',
			)
		);
		return (string) ob_get_clean();
	}

	// ── My applications (personal area) ──────────────────────────────────────

	/**
	 * Render the applicant's personal applications area.
	 *
	 * @return string Rendered HTML markup.
	 */
	public static function render_my_applications(): string {
		// Said again here, as the console does. The check on template_redirect
		// can miss a page whose shortcode a builder keeps out of the content,
		// and this screen shows live data behind a nonce: a cached copy is
		// both stale and unusable.
		Kivun_Core::no_cache();

		ob_start();
		kivun_get_template( 'applicant/my-applications.php' );
		return ob_get_clean();
	}

	// ── Employer register ─────────────────────────────────────────────────────

	/**
	 * Render the employer registration form.
	 *
	 * @return string Rendered HTML markup.
	 */
	public static function render_employer_register(): string {
		ob_start();
		kivun_get_template( 'employer/register-form.php' );
		return ob_get_clean();
	}

	// ── Employer dashboard ────────────────────────────────────────────────────

	/**
	 * Render the employer dashboard.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Rendered HTML markup.
	 */
	public static function render_employer_dashboard( array $atts ): string { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Shortcode callback signature.
		// Said again here, as the console does. The check on template_redirect
		// can miss a page whose shortcode a builder keeps out of the content,
		// and this screen shows live data behind a nonce: a cached copy is
		// both stale and unusable.
		Kivun_Core::no_cache();

		ob_start();
		kivun_get_template( 'employer/dashboard.php' );
		return ob_get_clean();
	}
}
